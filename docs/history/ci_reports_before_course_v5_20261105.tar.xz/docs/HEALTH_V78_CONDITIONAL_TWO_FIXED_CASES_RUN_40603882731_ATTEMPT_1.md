# V7.8 用户两张原始四柱真实Python／Swift同盘逐字核对

真实原时辰未改变，1930等其它历史断案均未覆盖。传统古籍象意非医学病情或预后事实。

## 同事（年命乙）
原四柱 {'year': '己丑', 'month': '戊辰', 'day': '辛卯', 'hour': '丁酉'}；时间 2009-04-16T17:00:00-04:00
三个步骤实盘账本：
一、各唯一实宫：{"1": {"version": "user_health_five_grade_signed_20261025_v3_void_mitigates_and_restores", "status": "saturated_five_grade", "components": {"star": -3, "door": -4, "deity": -4, "pattern": -5}, "component_instances": {"star": [-3], "door": [-4], "deity": [-4], "pattern": [-5]}, "known_neutral_door": false, "unresolved_categories": [], "known_subtotal": -16, "raw_sum": -16, "score_before_void": -5, "void_adjustment": 0, "void_adjustment_rule": "positive_minus_3_negative_plus_3_zero_unchanged", "five_not_encounter": false, "door_break": true, "void_state": "not_void", "horse_cleared_void": false, "timing_can_refill_or_clash": null, "timing_rules_deferred": true, "score": -5, "grade": "极大凶", "raw_sum_exceeds_five": true, "saturated_from_raw": -16, "score_is_research_only": true, "unique_stem_scores": {}}, "3": {"version": "user_health_five_grade_signed_20261025_v3_void_mitigates_and_restores", "status": "saturated_five_grade", "components": {"star": 1, "door": 3, "deity": 3, "pattern": 5}, "component_instances": {"star": [1], "door": [3], "deity": [3], "pattern": [5]}, "known_neutral_door": false, "unresolved_categories": [], "known_subtotal": 12, "raw_sum": 16, "score_before_void": 3, "void_adjustment": 0, "void_adjustment_rule": "positive_minus_3_negative_plus_3_zero_unchanged", "five_not_encounter": false, "door_break": true, "void_state": "not_void", "horse_cleared_void": false, "timing_can_refill_or_clash": null, "timing_rules_deferred": true, "score": 3, "grade": "中等吉", "raw_sum_exceeds_five": true, "saturated_from_raw": 12, "score_is_research_only": true, "unique_stem_scores": {"乙": 4}}, "8": {"version": "user_health_five_grade_signed_20261025_v3_void_mitigates_and_restores", "status": "saturated_five_grade", "components": {"star": -2, "door": -5, "deity": -4, "pattern": 0}, "component_instances": {"star": [-2], "door": [-5], "deity": [-4], "pattern": [0]}, "known_neutral_door": false, "unresolved_categories": [], "known_subtotal": -11, "raw_sum": -11, "score_before_void": -5, "void_adjustment": 0, "void_adjustment_rule": "positive_minus_3_negative_plus_3_zero_unchanged", "five_not_encounter": false, "door_break": false, "void_state": "not_void", "horse_cleared_void": false, "timing_can_refill_or_clash": null, "timing_rules_deferred": true, "score": -5, "grade": "极大凶", "raw_sum_exceeds_five": true, "saturated_from_raw": -11, "score_is_research_only": true, "unique_stem_scores": {"戊": 0}}, "7": {"version": "user_health_five_grade_signed_20261025_v3_void_mitigates_and_restores", "status": "saturated_five_grade", "components": {"star": 1, "door": 0, "deity": 2, "pattern": 5}, "component_instances": {"star": [1], "door": [0], "deity": [2], "pattern": [5]}, "known_neutral_door": true, "unresolved_categories": [], "known_subtotal": 8, "raw_sum": 12, "score_before_void": 5, "void_adjustment": 0, "void_adjustment_rule": "positive_minus_3_negative_plus_3_zero_unchanged", "five_not_encounter": false, "door_break": false, "void_state": "not_void", "horse_cleared_void": false, "timing_can_refill_or_clash": null, "timing_rules_deferred": true, "score": 5, "grade": "极大吉", "raw_sum_exceeds_five": true, "saturated_from_raw": 8, "score_is_research_only": true, "unique_stem_scores": {"丁": 4}}, "4": {"version": "user_health_five_grade_signed_20261025_v3_void_mitigates_and_restores", "status": "calculated", "components": {"star": -1, "door": 1, "deity": 2, "pattern": 2}, "component_instances": {"star": [-1], "door": [1], "deity": [2], "pattern": [2]}, "known_neutral_door": false, "unresolved_categories": [], "known_subtotal": 4, "raw_sum": 4, "score_before_void": 4, "void_adjustment": 0, "void_adjustment_rule": "positive_minus_3_negative_plus_3_zero_unchanged", "five_not_encounter": false, "door_break": false, "void_state": "not_void", "horse_cleared_void": true, "timing_can_refill_or_clash": null, "timing_rules_deferred": true, "score": 4, "grade": "大吉", "raw_sum_exceeds_five": false, "saturated_from_raw": null, "score_is_research_only": true, "unique_stem_scores": {}}}
二、额外有效克病：{"8": 3}；特殊同宫吉助：{"3:同宫吉助": {"palace": 3, "symbol": "天盘乙奇", "points": 3, "before_void": 3, "note": "震三宫得天盘乙奇同宫扶助。", "cohost": true}, "3:天心星": {"palace": 3, "symbol": "天心星", "points": 2, "note": "震三宫天心星势极小，吉助有限。"}, "7:同宫吉助": {"palace": 7, "symbol": "天盘丁奇", "points": 3, "before_void": 3, "note": "兑七宫得天盘丁奇同宫扶助。", "cohost": true}}
三、原宫合计2；独立吉助8；跨宫3；耗泄0；五不遇时扣10；净值3；最终3
### 动态两段结论
无整盘伏吟反吟，缓急另核；五不遇时成立，各实际参与实宫均减两分；天芮病宫落坎一宫，宫象极大凶；天心医生落震三宫，宫象中吉，受病宫生；乙奇医药与天心医生同在震三宫；患者用神落艮八宫，宫象极大凶，克病宫，本宫有力制病；时干事体落兑七宫，宫象极大吉，生扶病宫；值符落巽四宫，宫象大吉，受病宫生；患者年命与天心医生同在震三宫；震三宫得天盘乙奇同宫扶助；震三宫天心星势极小，吉助有限；兑七宫得天盘丁奇同宫扶助。

综上所述，此病为中吉；以上只作传统古籍象意参考，不能据此判断真实病情。
### Python 本次原文
起盘总纲：五不遇时、伏吟、反吟：
五不遇时成立（时干丁克日干辛且阴阳相同）；按用户规则，五不遇时主诸事凶，为全局一项不利象，不能单凭此象断病亡。 九星非伏吟反吟、八门非伏吟反吟。本盘无整盘伏吟反吟，不凭此三项擅断缓急。 缓急不自动等于吉凶。

天芮病宫：
落坎一宫；九星天芮星中凶；八神玄武比和、大凶；八门死门大凶；天盘干壬势中等、地盘干辛势极大；天地格：壬加辛「螣蛇相缠」（凶）。古文：纵得吉门，亦不能安；古诀大意：纠缠、欺骗，即使有助力也难完全安定；天地盘取象：壬为螣蛇，辛为白虎刑狱，两股纠缠力量交织，如蛇被牢狱之绳缠住；空亡不空；门破。八门压制宫力量，吉事不吉，凶事更凶。全部因素推断后，此宫为极大凶。 传统病星格局「病情扩散」。

天心医生：
落震三宫；九星天心星极小吉；八神九天克宫、中吉；八门开门中吉；天盘干乙势大、地盘干癸势中等；天地格：乙加癸「华盖青龙」（吉）。古文：遁迹修道，隐匿藏形；古诀大意：隐藏自己、避开灾难为宜；天地盘取象：癸为甲寅华盖，乙为青龙之木，如青龙藏在华盖之下；空亡不空；门破。八门压制宫力量，吉事不吉，凶事更凶。全部因素推断后，此宫为中吉。 天心星月令废、克宫，用神力量为极小。天心医生宫受天芮病宫生，意思为：本宫受病宫生扶，未形成对病宫的克制。

乙奇医药：
与前述天心医生同在震三宫，合看该宫象。 乙天干十二长生长生/冠带/临官/帝旺/沐浴、克月令，用神力量为大。乙奇医药宫受天芮病宫生，意思为：本宫受病宫生扶，未形成对病宫的克制。

患者用神：
落艮八宫；九星天柱星小凶；八神九地比和、大凶；八门惊门极大凶；天盘干戊、地盘干己势极小；天地格：戊加己「贵人入狱」（凶）。古文：公私皆不利；古诀大意：贵人受困，行动受阻；天地盘取象：戊藏甲子，己藏甲戌，戌为火墓及土库，借墓库比作关押贵人的牢狱；空亡不空；地盘入墓。全部因素推断后，此宫为极大凶。 戊天干与月令关系为比和，其本宫力量仍待核实。患者用神宫克天芮病宫，病象受到患者用神的克制。

时干事体：
落兑七宫；九星天辅星极小吉；八神六合被宫克、小吉；八门杜门中平；天盘干丁势大、地盘干戊势极小；天地格：丁加戊「青龙转光」（吉）。古文：官人升迁，常人咸昌；古诀大意：事业与声望提升；天地盘取象：戊藏甲木青龙，生助丁火星奇，青龙将光明转给星奇；空亡不空；门迫。全部因素推断后，此宫为极大吉。 丁天干十二长生长生/冠带/临官/帝旺/沐浴、生月令，用神力量为大。时干事体宫生天芮病宫，意思为：疾病得不到时干事体的压制，反受其生扶。

值符护持宫：
落巽四宫；九星天蓬星极小凶；八神值符被宫克、小吉；八门休门极小吉；天盘干辛势小、地盘干丁；天地格：辛加丁「狱神得奇」（吉）。古文：经商获倍利，囚人逢赦宥；古诀大意：受困者有解，财事有利；天地盘取象：辛为狱神，丁为星奇阴火，丁火克辛金，如光明进入监狱、破除约束；空亡不空；天盘入墓。全部因素推断后，此宫为大吉。 值符按神宫被宫克，用神力量为小。值符大吉神宫受天芮病宫生，意思为：本宫受病宫生扶，未形成对病宫的克制。

患者年命：
与前述天心医生同在震三宫，合看该宫象。

全部证据合断：
无整盘伏吟反吟，缓急另核；五不遇时成立，各实际参与实宫均减两分；天芮病宫落坎一宫，宫象极大凶；天心医生落震三宫，宫象中吉，受病宫生；乙奇医药与天心医生同在震三宫；患者用神落艮八宫，宫象极大凶，克病宫，本宫有力制病；时干事体落兑七宫，宫象极大吉，生扶病宫；值符落巽四宫，宫象大吉，受病宫生；患者年命与天心医生同在震三宫；震三宫得天盘乙奇同宫扶助；震三宫天心星势极小，吉助有限；兑七宫得天盘丁奇同宫扶助。

综上所述，此病为中吉；以上只作传统古籍象意参考，不能据此判断真实病情。

时空及应期：
时马在亥；应期须另有空、墓、冲合及问事情境支持，不能直接断定某一天。
### Native Swift 全文
起盘总纲：五不遇时、伏吟、反吟：
五不遇时成立（时干丁克日干辛且阴阳相同）；按用户规则，五不遇时主诸事凶，为全局一项不利象，不能单凭此象断病亡。 九星非伏吟反吟、八门非伏吟反吟。本盘无整盘伏吟反吟，不凭此三项擅断缓急。 缓急不自动等于吉凶。

天芮病宫：
落坎一宫；九星天芮星中凶；八神玄武比和、大凶；八门死门大凶；天盘干壬势中等、地盘干辛势极大；天地格：壬加辛「螣蛇相缠」（凶）。古文：纵得吉门，亦不能安；古诀大意：纠缠、欺骗，即使有助力也难完全安定；天地盘取象：壬为螣蛇，辛为白虎刑狱，两股纠缠力量交织，如蛇被牢狱之绳缠住；空亡不空；门破。八门压制宫力量，吉事不吉，凶事更凶。全部因素推断后，此宫为极大凶。 传统病星格局「病情扩散」。

天心医生：
落震三宫；九星天心星极小吉；八神九天克宫、中吉；八门开门中吉；天盘干乙势大、地盘干癸势中等；天地格：乙加癸「华盖青龙」（吉）。古文：遁迹修道，隐匿藏形；古诀大意：隐藏自己、避开灾难为宜；天地盘取象：癸为甲寅华盖，乙为青龙之木，如青龙藏在华盖之下；空亡不空；门破。八门压制宫力量，吉事不吉，凶事更凶。全部因素推断后，此宫为中吉。 天心星月令废、克宫，用神力量为极小。天心医生宫受天芮病宫生，意思为：本宫受病宫生扶，未形成对病宫的克制。

乙奇医药：
与前述天心医生同在震三宫，合看该宫象。 乙天干十二长生长生/冠带/临官/帝旺/沐浴、克月令，用神力量为大。乙奇医药宫受天芮病宫生，意思为：本宫受病宫生扶，未形成对病宫的克制。

患者用神：
落艮八宫；九星天柱星小凶；八神九地比和、大凶；八门惊门极大凶；天盘干戊、地盘干己势极小；天地格：戊加己「贵人入狱」（凶）。古文：公私皆不利；古诀大意：贵人受困，行动受阻；天地盘取象：戊藏甲子，己藏甲戌，戌为火墓及土库，借墓库比作关押贵人的牢狱；空亡不空；地盘入墓。全部因素推断后，此宫为极大凶。 戊天干与月令关系为比和，其本宫力量仍待核实。患者用神宫克天芮病宫，病象受到患者用神的克制。

时干事体：
落兑七宫；九星天辅星极小吉；八神六合被宫克、小吉；八门杜门中平；天盘干丁势大、地盘干戊势极小；天地格：丁加戊「青龙转光」（吉）。古文：官人升迁，常人咸昌；古诀大意：事业与声望提升；天地盘取象：戊藏甲木青龙，生助丁火星奇，青龙将光明转给星奇；空亡不空；门迫。全部因素推断后，此宫为极大吉。 丁天干十二长生长生/冠带/临官/帝旺/沐浴、生月令，用神力量为大。时干事体宫生天芮病宫，意思为：疾病得不到时干事体的压制，反受其生扶。

值符护持宫：
落巽四宫；九星天蓬星极小凶；八神值符被宫克、小吉；八门休门极小吉；天盘干辛势小、地盘干丁；天地格：辛加丁「狱神得奇」（吉）。古文：经商获倍利，囚人逢赦宥；古诀大意：受困者有解，财事有利；天地盘取象：辛为狱神，丁为星奇阴火，丁火克辛金，如光明进入监狱、破除约束；空亡不空；天盘入墓。全部因素推断后，此宫为大吉。 值符按神宫被宫克，用神力量为小。值符大吉神宫受天芮病宫生，意思为：本宫受病宫生扶，未形成对病宫的克制。

患者年命：
与前述天心医生同在震三宫，合看该宫象。

全部证据合断：
无整盘伏吟反吟，缓急另核；五不遇时成立，各实际参与实宫均减两分；天芮病宫落坎一宫，宫象极大凶；天心医生落震三宫，宫象中吉，受病宫生；乙奇医药与天心医生同在震三宫；患者用神落艮八宫，宫象极大凶，克病宫，本宫有力制病；时干事体落兑七宫，宫象极大吉，生扶病宫；值符落巽四宫，宫象大吉，受病宫生；患者年命与天心医生同在震三宫；震三宫得天盘乙奇同宫扶助；震三宫天心星势极小，吉助有限；兑七宫得天盘丁奇同宫扶助。

综上所述，此病为中吉；以上只作传统古籍象意参考，不能据此判断真实病情。

时空及应期：
时马在亥；应期须另有空、墓、冲合及问事情境支持，不能直接断定某一天。
全部原文逐字同一：True

## 1920女性长辈（条件年命庚申）
原四柱 {'year': '己丑', 'month': '庚午', 'day': '丁亥', 'hour': '乙巳'}；时间 2009-06-11T09:00:00-04:00
三个步骤实盘账本：
一、各唯一实宫：{"9": {"version": "user_health_five_grade_signed_20261025_v3_void_mitigates_and_restores", "status": "saturated_five_grade", "components": {"star": -2, "door": 5, "deity": 2, "pattern": 5}, "component_instances": {"star": [-2], "door": [5], "deity": [2], "pattern": [5]}, "known_neutral_door": false, "unresolved_categories": [], "known_subtotal": 10, "raw_sum": 11, "score_before_void": 5, "void_adjustment": 0, "void_adjustment_rule": "positive_minus_3_negative_plus_3_zero_unchanged", "five_not_encounter": false, "door_break": false, "void_state": "not_void", "horse_cleared_void": false, "timing_can_refill_or_clash": null, "timing_rules_deferred": true, "score": 5, "grade": "极大吉", "raw_sum_exceeds_five": true, "saturated_from_raw": 10, "score_is_research_only": true, "unique_stem_scores": {"乙": 4, "庚": -3}}, "7": {"version": "user_health_five_grade_signed_20261025_v3_void_mitigates_and_restores", "status": "saturated_five_grade", "components": {"star": 2, "door": 0, "deity": -3, "pattern": -5}, "component_instances": {"star": [2], "door": [0], "deity": [-3], "pattern": [-5]}, "known_neutral_door": true, "unresolved_categories": [], "known_subtotal": -6, "raw_sum": -6, "score_before_void": -5, "void_adjustment": 0, "void_adjustment_rule": "positive_minus_3_negative_plus_3_zero_unchanged", "five_not_encounter": false, "door_break": false, "void_state": "not_void", "horse_cleared_void": false, "timing_can_refill_or_clash": null, "timing_rules_deferred": true, "score": -5, "grade": "极大凶", "raw_sum_exceeds_five": true, "saturated_from_raw": -6, "score_is_research_only": true, "unique_stem_scores": {}}, "3": {"version": "user_health_five_grade_signed_20261025_v3_void_mitigates_and_restores", "status": "void_signed_three_shift", "components": {"star": 5, "door": 1, "deity": -3, "pattern": 3}, "component_instances": {"star": [5], "door": [1], "deity": [-3], "pattern": [3]}, "known_neutral_door": false, "unresolved_categories": [], "known_subtotal": 6, "raw_sum": 6, "score_before_void": 3, "void_adjustment": -3, "void_adjustment_rule": "positive_minus_3_negative_plus_3_zero_unchanged", "five_not_encounter": false, "door_break": true, "void_state": "true_void", "horse_cleared_void": false, "timing_can_refill_or_clash": false, "timing_rules_deferred": true, "score": 0, "grade": "中性0分", "raw_sum_exceeds_five": true, "saturated_from_raw": 6, "score_is_research_only": true, "unique_stem_scores": {"己": 0}}, "2": {"version": "user_health_five_grade_signed_20261025_v3_void_mitigates_and_restores", "status": "calculated", "components": {"star": -3, "door": -2, "deity": 4, "pattern": 0}, "component_instances": {"star": [-3], "door": [-2], "deity": [4], "pattern": [0]}, "known_neutral_door": false, "unresolved_categories": [], "known_subtotal": -1, "raw_sum": -1, "score_before_void": -3, "void_adjustment": 0, "void_adjustment_rule": "positive_minus_3_negative_plus_3_zero_unchanged", "five_not_encounter": false, "door_break": true, "void_state": "not_void", "horse_cleared_void": false, "timing_can_refill_or_clash": null, "timing_rules_deferred": true, "score": -3, "grade": "中等凶", "raw_sum_exceeds_five": false, "saturated_from_raw": null, "score_is_research_only": true, "unique_stem_scores": {}}}
二、额外有效克病：{}；特殊同宫吉助：{"2:同宫吉助": {"palace": 2, "symbol": "值符", "points": 3, "before_void": 3, "note": "坤二宫得值符同宫扶助。", "cohost": true}, "9:同宫吉助": {"palace": 9, "symbol": "天盘乙奇、地盘丁奇", "points": 3, "before_void": 3, "note": "离九宫得天盘乙奇与地盘丁奇同宫扶助。", "cohost": true}}
三、原宫合计-3；独立吉助6；跨宫0；耗泄0；五不遇时扣0；净值3；最终3
### 动态两段结论
无整盘伏吟反吟，缓急另核；天芮病宫落离九宫，宫象极大吉；天心医生落兑七宫，宫象极大凶，受病宫克；乙奇医药与天芮病宫同在离九宫；患者用神落震三宫，宫象中平且逢真空，生扶病宫；时干事体与天芮病宫同在离九宫；值符落坤二宫，宫象中凶，受病宫生；患者年命与天芮病宫同在离九宫；长辈坤宫与值符同在坤二宫；坤二宫得值符同宫扶助；离九宫得天盘乙奇与地盘丁奇同宫扶助。

综上所述，此病为中吉；以上只作传统古籍象意参考，不能据此判断真实病情。
### Python 本次原文
起盘总纲：五不遇时、伏吟、反吟：
不构成五不遇时（已按日干、时干五行克制及阴阳同类核对）。 九星非伏吟反吟、八门非伏吟反吟。本盘无整盘伏吟反吟，不凭此三项擅断缓急。 缓急不自动等于吉凶。

天芮病宫：
落离九宫；九星天芮星小凶；八神九天被宫克、小吉；八门生门极大吉；天盘干乙势大、地盘干丁势极大；天地格：乙加丁「奇仪相佐」（吉）。古文：文书事吉，百事可为；古诀大意：文书和合作事务顺利；天地盘取象：乙木生丁火，日奇扶助星奇，如两位助手彼此协作；空亡不空；无已核特殊刑墓迫。全部因素推断后，此宫为极大吉。 传统病星格局「百足之虫」。

天心医生：
落兑七宫；九星天心星小吉；八神螣蛇克宫、中凶；八门杜门中平；天盘干辛势中等、地盘干壬势大；天地格：辛加壬「凶蛇入狱」（凶）。古文：两男争女，讼事不息；古诀大意：多方争执，难以停止；天地盘取象：辛为白虎及牢狱，壬为甲辰螣蛇，蛇落白虎牢笼，如被纠缠拘禁；空亡不空；门迫。全部因素推断后，此宫为极大凶。 天心星月令囚、比和，用神力量为小。天心医生宫受天芮病宫克，意思为：天心医生受病宫压制，无法制病。

乙奇医药：
与前述天芮病宫同在离九宫，合看该宫象。 乙天干十二长生长生/冠带/临官/帝旺/沐浴、生月令，用神力量为大。乙奇与天芮病宫同宫，表示正在接受治疗，医药与病象同宫发挥作用。

患者用神：
落震三宫；九星天辅星极大吉；八神玄武生宫、中凶；八门开门极小吉；天盘干己势大、地盘干戊势极大；天地格：己加戊「犬遇青龙」（吉）。古文：门吉谋为遂意，上人见喜；古诀大意：有靠山，吉门下谋事顺利；天地盘取象：己为甲戌己，戌在十二生肖属犬；戊为甲子戊，甲取青龙之象，所以是犬遇青龙，象征地位较低者遇贵人；空亡真空；门破。八门压制宫力量，吉事不吉，凶事更凶。全部因素推断后，此宫为中平。 己天干十二长生衰 / 病、被月令生，用神力量为大。患者用神宫生天芮病宫，意思为：疾病得不到患者用神的压制，反受其生扶。

时干事体：
与前述天芮病宫同在离九宫，合看该宫象。

值符护持宫：
落坤二宫；九星天柱星中凶；八神值符比和、大吉；八门伤门小凶；天盘干壬、地盘干乙势中等；天地格：壬加乙「小蛇」（吉）。古文：女人柔顺，男子嗟呀；古诀大意：柔顺与阻滞并存；天地盘取象：壬为甲辰小蛇、阳水，乙为柔木日奇，水生木，如小蛇依附柔木生长；空亡不空；门破。八门压制宫力量，吉事不吉，凶事更凶。全部因素推断后，此宫为中凶。 值符按神宫比和，用神力量为大。值符大吉神宫受天芮病宫生，意思为：本宫受病宫生扶，未形成对病宫的克制。

患者年命：
与前述天芮病宫同在离九宫，合看该宫象。 庚天干十二长生长生/冠带/临官/帝旺/沐浴、被月令克，用神力量为中等。患者年命与天芮病宫同宫，意思为：双方同宫，不另论跨宫克制。

坤宫辅助（女）：
与前述值符护持宫同在坤二宫，合看该宫象。 天柱星月令囚、被宫生，用神力量为中等。性别辅助宫宫受天芮病宫生，意思为：本宫受病宫生扶，未形成对病宫的克制。

全部证据合断：
无整盘伏吟反吟，缓急另核；天芮病宫落离九宫，宫象极大吉；天心医生落兑七宫，宫象极大凶，受病宫克；乙奇医药与天芮病宫同在离九宫；患者用神落震三宫，宫象中平且逢真空，生扶病宫；时干事体与天芮病宫同在离九宫；值符落坤二宫，宫象中凶，受病宫生；患者年命与天芮病宫同在离九宫；长辈坤宫与值符同在坤二宫；坤二宫得值符同宫扶助；离九宫得天盘乙奇与地盘丁奇同宫扶助。

综上所述，此病为中吉；以上只作传统古籍象意参考，不能据此判断真实病情。

时空及应期：
时马在亥；应期须另有空、墓、冲合及问事情境支持，不能直接断定某一天。
### Native Swift 全文
起盘总纲：五不遇时、伏吟、反吟：
不构成五不遇时（已按日干、时干五行克制及阴阳同类核对）。 九星非伏吟反吟、八门非伏吟反吟。本盘无整盘伏吟反吟，不凭此三项擅断缓急。 缓急不自动等于吉凶。

天芮病宫：
落离九宫；九星天芮星小凶；八神九天被宫克、小吉；八门生门极大吉；天盘干乙势大、地盘干丁势极大；天地格：乙加丁「奇仪相佐」（吉）。古文：文书事吉，百事可为；古诀大意：文书和合作事务顺利；天地盘取象：乙木生丁火，日奇扶助星奇，如两位助手彼此协作；空亡不空；无已核特殊刑墓迫。全部因素推断后，此宫为极大吉。 传统病星格局「百足之虫」。

天心医生：
落兑七宫；九星天心星小吉；八神螣蛇克宫、中凶；八门杜门中平；天盘干辛势中等、地盘干壬势大；天地格：辛加壬「凶蛇入狱」（凶）。古文：两男争女，讼事不息；古诀大意：多方争执，难以停止；天地盘取象：辛为白虎及牢狱，壬为甲辰螣蛇，蛇落白虎牢笼，如被纠缠拘禁；空亡不空；门迫。全部因素推断后，此宫为极大凶。 天心星月令囚、比和，用神力量为小。天心医生宫受天芮病宫克，意思为：天心医生受病宫压制，无法制病。

乙奇医药：
与前述天芮病宫同在离九宫，合看该宫象。 乙天干十二长生长生/冠带/临官/帝旺/沐浴、生月令，用神力量为大。乙奇与天芮病宫同宫，表示正在接受治疗，医药与病象同宫发挥作用。

患者用神：
落震三宫；九星天辅星极大吉；八神玄武生宫、中凶；八门开门极小吉；天盘干己势大、地盘干戊势极大；天地格：己加戊「犬遇青龙」（吉）。古文：门吉谋为遂意，上人见喜；古诀大意：有靠山，吉门下谋事顺利；天地盘取象：己为甲戌己，戌在十二生肖属犬；戊为甲子戊，甲取青龙之象，所以是犬遇青龙，象征地位较低者遇贵人；空亡真空；门破。八门压制宫力量，吉事不吉，凶事更凶。全部因素推断后，此宫为中平。 己天干十二长生衰 / 病、被月令生，用神力量为大。患者用神宫生天芮病宫，意思为：疾病得不到患者用神的压制，反受其生扶。

时干事体：
与前述天芮病宫同在离九宫，合看该宫象。

值符护持宫：
落坤二宫；九星天柱星中凶；八神值符比和、大吉；八门伤门小凶；天盘干壬、地盘干乙势中等；天地格：壬加乙「小蛇」（吉）。古文：女人柔顺，男子嗟呀；古诀大意：柔顺与阻滞并存；天地盘取象：壬为甲辰小蛇、阳水，乙为柔木日奇，水生木，如小蛇依附柔木生长；空亡不空；门破。八门压制宫力量，吉事不吉，凶事更凶。全部因素推断后，此宫为中凶。 值符按神宫比和，用神力量为大。值符大吉神宫受天芮病宫生，意思为：本宫受病宫生扶，未形成对病宫的克制。

患者年命：
与前述天芮病宫同在离九宫，合看该宫象。 庚天干十二长生长生/冠带/临官/帝旺/沐浴、被月令克，用神力量为中等。患者年命与天芮病宫同宫，意思为：双方同宫，不另论跨宫克制。

坤宫辅助（女）：
与前述值符护持宫同在坤二宫，合看该宫象。 天柱星月令囚、被宫生，用神力量为中等。性别辅助宫宫受天芮病宫生，意思为：本宫受病宫生扶，未形成对病宫的克制。

全部证据合断：
无整盘伏吟反吟，缓急另核；天芮病宫落离九宫，宫象极大吉；天心医生落兑七宫，宫象极大凶，受病宫克；乙奇医药与天芮病宫同在离九宫；患者用神落震三宫，宫象中平且逢真空，生扶病宫；时干事体与天芮病宫同在离九宫；值符落坤二宫，宫象中凶，受病宫生；患者年命与天芮病宫同在离九宫；长辈坤宫与值符同在坤二宫；坤二宫得值符同宫扶助；离九宫得天盘乙奇与地盘丁奇同宫扶助。

综上所述，此病为中吉；以上只作传统古籍象意参考，不能据此判断真实病情。

时空及应期：
时马在亥；应期须另有空、墓、冲合及问事情境支持，不能直接断定某一天。
全部原文逐字同一：True
\nGitHub Actions原生原文运行链接：https://github.com/turnupmason/WenguaApp/actions/runs/40603882731\n